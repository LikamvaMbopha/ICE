﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CoffeeShop
{
    class Donuteer
    {
        public void WorkingDonuteer(ShopOrder o, EventArgs e)
        {
            MessageBox.Show("Baking Cozy Donuts!");
        }

        internal void WorkingDonuteer()
        {
            throw new NotImplementedException();
        }
    }
}
