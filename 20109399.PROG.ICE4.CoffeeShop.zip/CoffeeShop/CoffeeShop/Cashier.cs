﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CoffeeShop
{
    class Cashier
    {
        public void WorkingCashier(ShopOrder o, EventArgs e)
        {
            MessageBox.Show("Collect Cash from Customer!");
        }

        internal void WorkingCashier()
        {
            throw new NotImplementedException();
        }
    }
}
