﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeeShop
{
    class ShopOrder
    {
        private string name;
        private int numDonuts;
        private int numCoffee;

        public string Name { get => name; set => name = value; }
        public int NumDonuts { get => numDonuts; set => numDonuts = value; }
        public int NumCoffee { get => numCoffee; set => numCoffee = value; }
       
        public ShopOrder(string name, int numDonuts, int numCoffeee)
        {
            this.name = name;
            this.numDonuts = numDonuts;
            this.numCoffee = numCoffee;
        }

        public double OrderTotal()
        {
            return ((numDonuts * 12) + (numCoffee * 15));
        }
    }
}
 