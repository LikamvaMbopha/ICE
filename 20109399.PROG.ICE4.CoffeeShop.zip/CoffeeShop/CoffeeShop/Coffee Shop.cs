﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            string name = nameTB.Text;
            int numDonuts = Convert.ToInt32(donutsTB.Text);
            int numCoffee = Convert.ToInt32(coffeeTB.Text);

            ShopOrder o = new ShopOrder(name, numDonuts, numCoffee);

            MessageBox.Show("Customer: " + name + "\nOrder Total: R"
                + o.OrderTotal().ToString());

            ProcessOrder pOrder = new ProcessOrder();

            Cashier c = new Cashier();
            Donuteer d = new Donuteer();

            c.WorkingCashier();
            d.WorkingDonuteer();

            pOrder.OrderProcessed += c.WorkingCashier;
            pOrder.OrderProcessed += d.WorkingDonuteer;

            pOrder.Process(o);
        }
    }
}
