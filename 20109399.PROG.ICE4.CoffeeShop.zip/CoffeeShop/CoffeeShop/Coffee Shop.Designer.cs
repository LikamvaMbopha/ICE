﻿
namespace CoffeeShop
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.donutsTB = new System.Windows.Forms.TextBox();
            this.coffeeTB = new System.Windows.Forms.TextBox();
            this.confirmBtn = new System.Windows.Forms.Button();
            this.welcomeLbl = new System.Windows.Forms.Label();
            this.instructionLbl = new System.Windows.Forms.Label();
            this.donutsLbl = new System.Windows.Forms.Label();
            this.coffeeLbl = new System.Windows.Forms.Label();
            this.coffeePrice = new System.Windows.Forms.Label();
            this.donutPrice = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.nameLbl = new System.Windows.Forms.Label();
            this.nameTB = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // donutsTB
            // 
            this.donutsTB.Location = new System.Drawing.Point(319, 290);
            this.donutsTB.Name = "donutsTB";
            this.donutsTB.Size = new System.Drawing.Size(100, 26);
            this.donutsTB.TabIndex = 0;
            // 
            // coffeeTB
            // 
            this.coffeeTB.Location = new System.Drawing.Point(319, 322);
            this.coffeeTB.Name = "coffeeTB";
            this.coffeeTB.Size = new System.Drawing.Size(100, 26);
            this.coffeeTB.TabIndex = 1;
            // 
            // confirmBtn
            // 
            this.confirmBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.confirmBtn.Location = new System.Drawing.Point(319, 354);
            this.confirmBtn.Name = "confirmBtn";
            this.confirmBtn.Size = new System.Drawing.Size(100, 23);
            this.confirmBtn.TabIndex = 2;
            this.confirmBtn.Text = "CONFIRM";
            this.confirmBtn.UseVisualStyleBackColor = true;
            this.confirmBtn.Click += new System.EventHandler(this.confirmBtn_Click);
            // 
            // welcomeLbl
            // 
            this.welcomeLbl.AutoSize = true;
            this.welcomeLbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.welcomeLbl.Location = new System.Drawing.Point(101, 110);
            this.welcomeLbl.Name = "welcomeLbl";
            this.welcomeLbl.Size = new System.Drawing.Size(263, 24);
            this.welcomeLbl.TabIndex = 3;
            this.welcomeLbl.Text = "Welcome To Cozy Coffee";
            // 
            // instructionLbl
            // 
            this.instructionLbl.AutoSize = true;
            this.instructionLbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.instructionLbl.Location = new System.Drawing.Point(144, 234);
            this.instructionLbl.Name = "instructionLbl";
            this.instructionLbl.Size = new System.Drawing.Size(183, 15);
            this.instructionLbl.TabIndex = 4;
            this.instructionLbl.Text = "FILL IN THE ORDER BELOW";
            // 
            // donutsLbl
            // 
            this.donutsLbl.AutoSize = true;
            this.donutsLbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.donutsLbl.Location = new System.Drawing.Point(54, 296);
            this.donutsLbl.Name = "donutsLbl";
            this.donutsLbl.Size = new System.Drawing.Size(259, 15);
            this.donutsLbl.TabIndex = 5;
            this.donutsLbl.Text = "How many Cozy Donuts would you like: ";
            // 
            // coffeeLbl
            // 
            this.coffeeLbl.AutoSize = true;
            this.coffeeLbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.coffeeLbl.Location = new System.Drawing.Point(9, 328);
            this.coffeeLbl.Name = "coffeeLbl";
            this.coffeeLbl.Size = new System.Drawing.Size(304, 15);
            this.coffeeLbl.TabIndex = 6;
            this.coffeeLbl.Text = "How many Cozy cups of Coffee would you like: ";
            // 
            // coffeePrice
            // 
            this.coffeePrice.AutoSize = true;
            this.coffeePrice.Location = new System.Drawing.Point(144, 187);
            this.coffeePrice.Name = "coffeePrice";
            this.coffeePrice.Size = new System.Drawing.Size(169, 18);
            this.coffeePrice.TabIndex = 7;
            this.coffeePrice.Text = "COZY COFFEE - R15";
            // 
            // donutPrice
            // 
            this.donutPrice.AutoSize = true;
            this.donutPrice.Location = new System.Drawing.Point(144, 159);
            this.donutPrice.Name = "donutPrice";
            this.donutPrice.Size = new System.Drawing.Size(161, 18);
            this.donutPrice.TabIndex = 8;
            this.donutPrice.Text = "COZY DONUT - R12";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(36, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(375, 106);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, 234);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(438, 232);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(-1, 103);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(438, 136);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(-1, 1);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(438, 136);
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nameLbl.Location = new System.Drawing.Point(192, 264);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(121, 15);
            this.nameLbl.TabIndex = 14;
            this.nameLbl.Text = "Enter your name: ";
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(319, 258);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(100, 26);
            this.nameTB.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 468);
            this.Controls.Add(this.nameTB);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.donutPrice);
            this.Controls.Add(this.coffeePrice);
            this.Controls.Add(this.coffeeLbl);
            this.Controls.Add(this.donutsLbl);
            this.Controls.Add(this.instructionLbl);
            this.Controls.Add(this.welcomeLbl);
            this.Controls.Add(this.confirmBtn);
            this.Controls.Add(this.coffeeTB);
            this.Controls.Add(this.donutsTB);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "Form1";
            this.Text = "Coffee Shop";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox donutsTB;
        private System.Windows.Forms.TextBox coffeeTB;
        private System.Windows.Forms.Button confirmBtn;
        private System.Windows.Forms.Label welcomeLbl;
        private System.Windows.Forms.Label instructionLbl;
        private System.Windows.Forms.Label donutsLbl;
        private System.Windows.Forms.Label coffeeLbl;
        private System.Windows.Forms.Label coffeePrice;
        private System.Windows.Forms.Label donutPrice;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.TextBox nameTB;
    }
}

