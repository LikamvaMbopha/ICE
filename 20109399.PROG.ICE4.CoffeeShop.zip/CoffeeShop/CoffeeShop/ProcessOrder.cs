﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeeShop
{
    class ProcessOrder
    {
        public delegate void ProcessOrderEventHandler(ShopOrder source, EventArgs e);

        public event ProcessOrderEventHandler OrderProcessed;

        public void Process(ShopOrder o) 
        {
            OnOrderProcessed(o);
        }

        public void OnOrderProcessed (ShopOrder o)
        {
            if (OrderProcessed != null)
            {
                OrderProcessed(o, EventArgs.Empty);
            }
        }
    }
}
