﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToodyDo
{
    class ToDo
    {
        enum Levels
        {
            Low, medium, High
        }

        private string entry;
        private string priority;

        public string Entry { get => entry; set => entry = value; }
        public string Priority { get => priority; set => priority = value; }

        public ToDo()
        {
            this.entry = entry;
            this.priority = priority;
        }
    }
}
