﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToodyDo
{
    public partial class ToodyDo : Form
    {
        public ToodyDo()
        {
            InitializeComponent();
        }

        private void fromToDo_Load(object sender, EventArgs e)
        {
            ListUtility.toDoList = toDoList.readFromFile();
            loadListBox();
        }

        private void loadListBox()
        {
            ToodyDo.Items.Clear();
            foreach (toDoList tDL in ListUtility.toDoList.OrderByDescending(1 => 1.Priority))
            {
                toDoList.Items.Add(tDL.ToString());
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            string entry = entryTB.Text;
            string priority = priorityCB.SelectedIndex;
        }

        public static List<ToDo> readFromFile()
        {
            List<ToDo> temporaryList = new List<ToDo>();

            using (StreamReader reader = new StreamReader("ToodyDoList.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] lineParts = line.Split('#');
                    string description = lineParts[0];

                    string date = lineParts[1];

                    string[] dateParts = date.Split("/");
                    int day = Convert.ToInt32(dateParts[2].Substring(0, 2));
                    int month = Convert.ToInt32(dateParts[1]);
                    int year = Convert.ToInt32(dateParts[0]);

                    DateTime dT = new DateTime(day, month, year);

                    string priority = lineParts[2];
                    ToDo.priority levels;
                    switch (priority)
                    {
                        case "Low":
                            levels = ToDo.priority.Low;
                            break;
                        case "Medium":
                            levels = ToDo.priority.Medium;
                            break;
                        default:
                            levels = ToDo.priority.High;
                            break;
                    }

                    ToDo tDL = new ToDo(description, date, levels);
                    temporaryList.Add(tDL);
                }

                return (temporaryList);
            }
        }
}
