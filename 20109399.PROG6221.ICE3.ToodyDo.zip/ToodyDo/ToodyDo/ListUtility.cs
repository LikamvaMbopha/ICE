﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToodyDo
{
    class ListUtility
    {
        public static List<ToDo> toDoList = new List<ToDo>();
    }
}
