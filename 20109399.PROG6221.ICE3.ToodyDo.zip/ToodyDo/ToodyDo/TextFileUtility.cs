﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToodyDo
{
    class TextFileUtility
    {
        public static List<ToDo> readFromfile = new List<ToDo>();
    }
}
