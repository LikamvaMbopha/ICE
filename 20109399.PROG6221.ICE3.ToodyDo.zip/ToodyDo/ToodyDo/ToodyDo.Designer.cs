﻿
namespace ToodyDo
{
    partial class ToodyDo
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLbl = new System.Windows.Forms.Label();
            this.instruction1Lbl = new System.Windows.Forms.Label();
            this.entryTB = new System.Windows.Forms.TextBox();
            this.entriesLB = new System.Windows.Forms.ListBox();
            this.priorityCB = new System.Windows.Forms.ComboBox();
            this.priorityLbl = new System.Windows.Forms.Label();
            this.addLbl = new System.Windows.Forms.Label();
            this.addBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // welcomeLbl
            // 
            this.welcomeLbl.AutoSize = true;
            this.welcomeLbl.Font = new System.Drawing.Font("Showcard Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.welcomeLbl.Location = new System.Drawing.Point(129, 9);
            this.welcomeLbl.Name = "welcomeLbl";
            this.welcomeLbl.Size = new System.Drawing.Size(273, 27);
            this.welcomeLbl.TabIndex = 0;
            this.welcomeLbl.Text = "WELCOME TO TOODYDO";
            // 
            // instruction1Lbl
            // 
            this.instruction1Lbl.AutoSize = true;
            this.instruction1Lbl.Location = new System.Drawing.Point(12, 60);
            this.instruction1Lbl.Name = "instruction1Lbl";
            this.instruction1Lbl.Size = new System.Drawing.Size(239, 15);
            this.instruction1Lbl.TabIndex = 1;
            this.instruction1Lbl.Text = "Enter something to do in the textbox below:";
            // 
            // entryTB
            // 
            this.entryTB.Location = new System.Drawing.Point(12, 78);
            this.entryTB.Name = "entryTB";
            this.entryTB.Size = new System.Drawing.Size(250, 23);
            this.entryTB.TabIndex = 2;
            // 
            // entriesLB
            // 
            this.entriesLB.FormattingEnabled = true;
            this.entriesLB.ItemHeight = 15;
            this.entriesLB.Location = new System.Drawing.Point(268, 78);
            this.entriesLB.Name = "entriesLB";
            this.entriesLB.Size = new System.Drawing.Size(280, 349);
            this.entriesLB.TabIndex = 3;
            // 
            // priorityCB
            // 
            this.priorityCB.FormattingEnabled = true;
            this.priorityCB.Items.AddRange(new object[] {
            "Low ",
            "Medium",
            "High"});
            this.priorityCB.Location = new System.Drawing.Point(12, 152);
            this.priorityCB.Name = "priorityCB";
            this.priorityCB.Size = new System.Drawing.Size(250, 23);
            this.priorityCB.TabIndex = 4;
            // 
            // priorityLbl
            // 
            this.priorityLbl.AutoSize = true;
            this.priorityLbl.Location = new System.Drawing.Point(12, 134);
            this.priorityLbl.Name = "priorityLbl";
            this.priorityLbl.Size = new System.Drawing.Size(231, 15);
            this.priorityLbl.TabIndex = 5;
            this.priorityLbl.Text = "Select a priority level for your entry below: ";
            // 
            // addLbl
            // 
            this.addLbl.AutoSize = true;
            this.addLbl.Location = new System.Drawing.Point(12, 210);
            this.addLbl.Name = "addLbl";
            this.addLbl.Size = new System.Drawing.Size(244, 15);
            this.addLbl.TabIndex = 6;
            this.addLbl.Text = "Press add below to add your entry to the list: ";
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(12, 228);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(250, 29);
            this.addBtn.TabIndex = 7;
            this.addBtn.Text = "ADD ENTRY";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // ToodyDo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 450);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.addLbl);
            this.Controls.Add(this.priorityLbl);
            this.Controls.Add(this.priorityCB);
            this.Controls.Add(this.entriesLB);
            this.Controls.Add(this.entryTB);
            this.Controls.Add(this.instruction1Lbl);
            this.Controls.Add(this.welcomeLbl);
            this.Name = "ToodyDo";
            this.Text = "ToodyDo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLbl;
        private System.Windows.Forms.Label instruction1Lbl;
        private System.Windows.Forms.TextBox entryTB;
        private System.Windows.Forms.ListBox entriesLB;
        private System.Windows.Forms.ComboBox priorityCB;
        private System.Windows.Forms.Label priorityLbl;
        private System.Windows.Forms.Label addLbl;
        private System.Windows.Forms.Button addBtn;
    }
}

